# Logging and Analytics Redaction — No PII Leakage

Date: 2025-09-20
Owners: Security, Platform Engineering
Related: shared-utils RedactionUtil, api-gateway, user-activity-logger, docs/runbooks/portals-signoff-checklist.md

Objective
- Ensure sensitive data (PII, secrets) are not written to logs or analytics.

Controls Implemented
- Code utility: shared-utils RedactionUtil.redact(String) masks email, phone-like numbers, SSN-like patterns, and Authorization Bearer tokens.
- Usage pattern: Apply RedactionUtil to any log message that includes user input or headers. Prefer structured logging with named fields and avoid dumping request bodies.
- Gateway: Optional DEBUG-only request logging should sanitize values using RedactionUtil.

Guidelines
- Never log full Authorization headers, access tokens, passwords, MFA codes, or full document payloads.
- Use correlation id only (x-correlation-id) to join logs; it is not PII and is exposed to clients.
- For errors, log identifiers (userId, centreId) instead of emails or names; if needed, mask with RedactionUtil.

Verification
- Unit tests: RedactionUtilTest asserts masking for email, phone, SSN, and Authorization token patterns.
- Manual: Grep recent logs for email patterns and SSN-like patterns; expect none.
- CI: Add a regex-based scan step (future) to fail builds if test logs leak PII patterns.

Future Enhancements
- Central logback-spring.xml with JSON layout and masking filters applied globally.
- Adopt Zalando Logbook or Spring Cloud Gateway Netty access logs with redaction.
