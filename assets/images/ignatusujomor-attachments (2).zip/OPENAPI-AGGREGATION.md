# OpenAPI Aggregation — API Gateway

Date: 2025-09-20
Owners: Platform Engineering
Related: api-gateway, docs/runbooks/portals-signoff-checklist.md

Goal
- Provide a single aggregated OpenAPI/Swagger UI entry-point that references downstream services used by the portals.

Current Status
- The gateway exposes routes for all core services (identity, email, affidavits, templates, documents, notary, updates, payments, comments).
- Aggregated OpenAPI is ENABLED in the gateway. Swagger UI is reachable at /swagger-ui.html and lists downstream services' OpenAPI via the gateway paths below.

Proposed Approach (Springdoc, WebFlux)
- Add dependency to api-gateway/pom.xml:
  - org.springdoc:springdoc-openapi-starter-webflux-ui:2.5.0
- Configure groups that pull downstream OpenAPI JSON via the gateway so auth and CORS policies are consistent.
- Expose:
  - /openapi
  - /swagger-ui.html

Example Configuration (properties)
```
springdoc:
  api-docs:
    enabled: true
    groups:
      enabled: true
  swagger-ui:
    enabled: true
    path: /swagger-ui.html
```

Downstream OpenAPI Endpoints (via Gateway)
- identity → /api/v1/identity/v3/api-docs
- affidavits → /api/v1/affidavits/v3/api-docs
- templates → /api/v1/templates/v3/api-docs
- documents → /api/v1/documents/v3/api-docs
- notary → /api/v1/notary/v3/api-docs
- payments → /api/v1/payments/v3/api-docs
- comments → /api/v1/comments/v3/api-docs
- email-notification → /api/v1/email-notification/v3/api-docs
- updater-service → /api/v1/updates/v3/api-docs

Work Items
1) Add springdoc dependency and basic config in api-gateway. (pending)
2) Verify each downstream exposes v3/api-docs; if not, add/enable. (pending)
3) Add an aggregator endpoint or UI that links groups per service. (pending)
4) Secure with ADMIN-only if needed. (pending)

Notes
- If some services do not publish OpenAPI, include them later; the approach is incremental.
- Keep gateway build lean; if footprint is a concern, expose only a static index with links to per-service docs through the gateway.
