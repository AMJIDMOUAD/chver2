# Error Budgets and SLAs — Critical Flows (Portals)

Date: 2025-09-20
Owners: Product, Platform Eng, SRE
Related: docs/runbooks/portals-signoff-checklist.md, docs/backend/HEALTH-CHECKS.md, docs/backend/IMPERSONATION-POLICY.md

Purpose
- Define reliability targets (SLAs/SLOs) and error budgets for critical user journeys across portals, to guide operations and release decisions.

Definitions
- SLA (external): Availability target over a calendar month for externally visible functions.
- SLO (internal): Tighter targets for engineering; SLIs measured via Prometheus/Grafana and logs.
- Error Budget: 1 - SLO over a period; represents permissible unreliability for changes.

Scope: Critical Flows
1) Deponent Portal
   - Submit affidavit (incl. form fill, attachments upload, final submit)
   - PDF preview generation
2) Notary Portal
   - View and accept queue item
   - Schedule and complete notarization
3) Support Desk
   - Ticket lifecycle operations (open → assign → resolve)
   - Assisted actions incl. impersonation (see policy)

Targets (initial)
- Availability (SLA):
  - Deponent submission API: 99.90%/month (error budget ≈ 43m)
  - Notary notarize API: 99.90%/month (error budget ≈ 43m)
  - Support tickets API: 99.90%/month (error budget ≈ 43m)
- Latency (SLO, p95):
  - Gateway routing p95 < 300ms
  - Document preview generation p95 < 2s
- Error Rate (SLO):
  - 5xx rate < 0.5% over 5m windows per service

Measurement
- Uptime: probe /actuator/health and domain-specific canary checks every 30s from multiple regions.
- Latency/Error: derive from /actuator/prometheus (HTTP server metrics, gateway metrics) and logs with correlation-id.
- Attribution: roll up per service with common tags: application, instance, service.

Policies
- Releases consume error budget; if exhausted, pause feature rollouts except for reliability/bugfixes.
- Any incident > 10 minutes requires postmortem with action items.
- Impersonation flows are audited; incidents in assisted actions are severity-raised.

Dashboards & Alerts
- Grafana dashboards per portal with the SLI panels and monthly budget burn-down.
- Alert rules:
  - p95 latency breach 10m → page team on-call (prod), Slack alert (staging)
  - 5xx rate breach 5m → page team on-call (prod)
  - Health check DOWN > 2m → page ops

Ownership
- Service owners maintain SLIs and update targets quarterly.
- QA to validate canary flows per env; link evidence in runbooks.

Change Log
- 2025-09-20: Initial draft committed; aligns with current gateway exposure and tracing.
