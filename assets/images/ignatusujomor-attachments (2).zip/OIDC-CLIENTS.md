# OIDC Clients — Registration Matrix (Web/Mobile)

Date: 2025-09-20
Owners: Security, Platform Engineering
Related: docs/runbooks/portals-signoff-checklist.md, api-gateway, authentication

Purpose
- Provide authoritative, backend-owned documentation for OIDC client registrations required by all portals and admin apps across environments.
- Ensure scopes and redirect URIs are defined and approved.

Identity Provider
- Recommended: Keycloak (realm: affiantor). Applicable to Auth0/Okta with equivalent fields.

Common Settings
- Grant: Authorization Code + PKCE
- Token lifetimes: Access 5–10m, Refresh 30d (web), 90d (mobile) — per policy
- Scopes: openid profile email offline_access api.read api.write

Clients (by environment)

Dev
- nexus_web
  - Redirect URIs: http://localhost:5173/auth/callback, http://localhost:5173/silent-renew
  - Post logout: http://localhost:5173/
  - Web origins: http://localhost:5173
  - Scopes: openid profile email offline_access api.read api.write
- notary_web
  - Redirect URIs: http://localhost:3000/auth/callback
  - Post logout: http://localhost:3000/
  - Web origins: http://localhost:3000
  - Scopes: openid profile email offline_access api.read
- support_web
  - Redirect URIs: http://localhost:3000/auth/callback
  - Post logout: http://localhost:3000/
  - Web origins: http://localhost:3000
  - Scopes: openid profile email offline_access api.read
- deponent_web
  - Redirect URIs: http://localhost:3000/auth/callback
  - Post logout: http://localhost:3000/
  - Web origins: http://localhost:3000
  - Scopes: openid profile email offline_access api.read
- mobile apps (optional, per platform)
  - notary_mobile: com.affiantor.notary:/oauthredirect
  - deponent_mobile: com.affiantor.deponent:/oauthredirect

Staging
- nexus_web
  - Redirect URIs: https://nexus.staging.affiantor.xyz/auth/callback, https://nexus.staging.affiantor.xyz/silent-renew
  - Post logout: https://nexus.staging.affiantor.xyz/
  - Web origins: https://nexus.staging.affiantor.xyz
  - Scopes: openid profile email offline_access api.read api.write
- notary_web
  - Redirect URIs: https://notary.staging.affiantor.xyz/auth/callback
  - Post logout: https://notary.staging.affiantor.xyz/
  - Web origins: https://notary.staging.affiantor.xyz
  - Scopes: openid profile email offline_access api.read
- support_web
  - Redirect URIs: https://support.staging.affiantor.xyz/auth/callback
  - Post logout: https://support.staging.affiantor.xyz/
  - Web origins: https://support.staging.affiantor.xyz
  - Scopes: openid profile email offline_access api.read
- deponent_web
  - Redirect URIs: https://deponent.staging.affiantor.xyz/auth/callback
  - Post logout: https://deponent.staging.affiantor.xyz/
  - Web origins: https://deponent.staging.affiantor.xyz
  - Scopes: openid profile email offline_access api.read

Prod
- nexus_web
  - Redirect URIs: https://nexus.affiantor.xyz/auth/callback, https://nexus.affiantor.xyz/silent-renew
  - Post logout: https://nexus.affiantor.xyz/
  - Web origins: https://nexus.affiantor.xyz
  - Scopes: openid profile email offline_access api.read api.write
- notary_web
  - Redirect URIs: https://notary.affiantor.xyz/auth/callback
  - Post logout: https://notary.affiantor.xyz/
  - Web origins: https://notary.affiantor.xyz
  - Scopes: openid profile email offline_access api.read
- support_web
  - Redirect URIs: https://support.affiantor.xyz/auth/callback
  - Post logout: https://support.affiantor.xyz/
  - Web origins: https://support.affiantor.xyz
  - Scopes: openid profile email offline_access api.read
- deponent_web
  - Redirect URIs: https://deponent.affiantor.xyz/auth/callback
  - Post logout: https://deponent.affiantor.xyz/
  - Web origins: https://deponent.affiantor.xyz
  - Scopes: openid profile email offline_access api.read

Keycloak JSON template (example)
{
  "clientId": "notary_web",
  "publicClient": true,
  "standardFlowEnabled": true,
  "attributes": {
    "pkce.code.challenge.method": "S256"
  },
  "redirectUris": ["https://notary.affiantor.xyz/auth/callback"],
  "webOrigins": ["https://notary.affiantor.xyz"],
  "defaultClientScopes": ["web-origins", "role_list", "profile", "email", "roles"],
  "optionalClientScopes": ["offline_access"]
}

Operational Notes
- Maintain clients via Terraform/Keycloak operator where possible. Track changes with ticket + PR.
- All URIs must be HTTPS in prod; no wildcards.
- Update env files for frontend with OIDC_* to match the registrations.
