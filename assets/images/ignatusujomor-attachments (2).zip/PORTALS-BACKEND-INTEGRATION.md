# Portals Backend Integration Matrix

Status: Placeholder

This document will summarize backend services, endpoints, and data flows used by Deponent, Notary, and Support portals across environments. To be completed.
