# Updater Module — Backend Design and Paste-&-Execute Setup Guide

Date: 2025-09-13
Owner: Backend Platform
Related: api-gateway, shared-utils, shared-security, docker/docker-compose.yml, tools/docker/Dockerfile.jvm

Purpose
- Provide a safe, minimal-impact backend module that exposes update/version policies for client apps.
- Support Mobile, Desktop, Web, and Hybrid approaches as per Best Practice Recommendations.
- Deliver copy/paste ready commands to scaffold, build, and run the new service without breaking existing code.

Overview
The updater-service centralizes client update policies and version metadata. Clients query it at startup and periodically to determine if an update is available, recommended, or required (force update). The service stores per-app and per-platform rules with semantic versions and returns the current policy.

Key Concepts
- App identifiers (appCode): nexus, notary, support, deponent (extendable)
- Platforms: android, ios, web, windows, macos, linux
- Policy fields:
  - latestVersion: semantic version string (e.g., 1.4.2)
  - minSupportedVersion: semantic version string
  - forceUpdate: boolean (true → block app usage until updated)
  - recommended: boolean (true → soft prompt)
  - releaseNotesUrl: optional
  - updateUrl: optional (store links, app store URLs, or desktop updater feeds)
  - cacheTtlSeconds: optional hint for client cache

API (v1)
- GET /api/v1/updates/policy?appCode=<code>&platform=<platform>&currentVersion=<semver>
  - Returns policy resolution for the requesting client version and platform.
- GET /api/v1/updates/config/{appCode}
  - Returns all stored policies for an app grouped by platform.
- PUT /api/v1/updates/config/{appCode}/{platform}
  - Upsert a platform policy (admin only in production). For dev, no auth or simple role guard is acceptable.


Quick Start — Paste & Execute (Windows PowerShell)
1) Create the module skeleton
- From repository root (contains pom.xml):

```powershell
# 1. Create module directory and minimal Maven project
mvn -q archetype:generate `
  -DgroupId=com.ujomorserver.updater `
  -DartifactId=updater-service `
  -Dpackage=com.ujomorserver.updater `
  -DarchetypeArtifactId=maven-archetype-quickstart `
  -DinteractiveMode=false

# 2. Replace generated pom.xml with Spring Boot setup
Set-Content -Path updater-service\pom.xml -Value @'
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>com.ujomorserver</groupId>
    <artifactId>affiantor</artifactId>
    <version>1.0.0-SNAPSHOT</version>
  </parent>
  <artifactId>updater-service</artifactId>
  <name>updater-service</name>
  <properties>
    <java.version>21</java.version>
    <spring.boot.version>3.4.7</spring.boot.version>
  </properties>
  <dependencies>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
      <groupId>org.mariadb.jdbc</groupId>
      <artifactId>mariadb-java-client</artifactId>
    </dependency>
    <dependency>
      <groupId>org.liquibase</groupId>
      <artifactId>liquibase-core</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springdoc</groupId>
      <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
      <version>2.6.0</version>
    </dependency>
    <dependency>
      <groupId>com.ujomorserver</groupId>
      <artifactId>shared-security</artifactId>
      <version>${project.parent.version}</version>
    </dependency>
    <dependency>
      <groupId>com.ujomorserver</groupId>
      <artifactId>shared-utils</artifactId>
      <version>${project.parent.version}</version>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
      </plugin>
    </plugins>
  </build>
</project>
'@

# 3. Add module to parent reactor
(Get-Content pom.xml) -replace '</modules>', '<module>updater-service</module></modules>' | Set-Content pom.xml

# 4. Create Spring Boot app class and basic package structure
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater | Out-Null
New-Item -ItemType Directory -Force updater-service\src\main\resources | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\UpdaterServiceApplication.java -Value @'
package com.ujomorserver.updater;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication(scanBasePackages = "com.ujomorserver")
@EnableDiscoveryClient
public class UpdaterServiceApplication {
  public static void main(String[] args) {
    SpringApplication.run(UpdaterServiceApplication.class, args);
  }
}
'@
```

2) Application configuration (resilient DB + Consul + JPA)

```powershell
Set-Content -Path updater-service\src\main\resources\application.yml -Value @'
spring:
  application:
    name: updater-service
  profiles:
    active: default
    include: shared-security
  cloud:
    consul:
      enabled: true
      host: ${CONSUL_HOST:localhost}
      port: '${CONSUL_PORT:8500}'
      discovery:
        enabled: true
        instanceId: updater-service
        service-name: updater-service
        heartbeat:
          use-actuator-health: true
        healthCheckPath: /actuator/health
        tags: [env=dev, service=updater-service]
  datasource:
    driver-class-name: org.mariadb.jdbc.Driver
    url: ${SPRING_DATASOURCE_URL:jdbc:mariadb://${DB_HOST:mariadb}:${DB_PORT:3306}/${DB_NAME:affiantordb}?createDatabaseIfNotExist=true&sessionVariables=sql_mode='NO_ENGINE_SUBSTITUTION'&jdbcCompliantTruncation=false}
    username: ${SPRING_DATASOURCE_USERNAME:affiantor}
    password: ${SPRING_DATASOURCE_PASSWORD:affiantorpass}
    hikari:
      initializationFailTimeout: 0
      connectionTimeout: 60000
  jpa:
    hibernate:
      ddl-auto: update
      naming:
        physical-strategy: org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl
    database-platform: org.hibernate.dialect.MariaDBDialect
    properties:
      hibernate:
        format_sql: true
        dialect: org.hibernate.dialect.MariaDBDialect
    open-in-view: false
  liquibase:
    change-log: classpath:db/changelog/db.changelog-master-updater.yaml
server:
  port: 0
management:
  endpoints:
    web:
      base-path: /actuator
      exposure:
        include: 'health,info,env'
'@

# Create Liquibase changelog
New-Item -ItemType Directory -Force updater-service\src\main\resources\db\changelog | Out-Null
Set-Content -Path updater-service\src\main\resources\db\changelog\db.changelog-master-updater.yaml -Value @'
databaseChangeLog:
  - changeSet:
      id: 1-create-update-policy
      author: platform
      changes:
        - createTable:
            tableName: update_policy
            columns:
              - column: {name: id, type: BIGINT, autoIncrement: true, constraints: {primaryKey: true}}
              - column: {name: app_code, type: VARCHAR(64), constraints: {nullable: false}}
              - column: {name: platform, type: VARCHAR(32), constraints: {nullable: false}}
              - column: {name: latest_version, type: VARCHAR(32), constraints: {nullable: false}}
              - column: {name: min_supported_version, type: VARCHAR(32), constraints: {nullable: false}}
              - column: {name: force_update, type: BOOLEAN, defaultValueBoolean: false}
              - column: {name: recommended, type: BOOLEAN, defaultValueBoolean: true}
              - column: {name: release_notes_url, type: VARCHAR(512)}
              - column: {name: update_url, type: VARCHAR(512)}
              - column: {name: cache_ttl_seconds, type: INT, defaultValueNumeric: 3600}
        - addUniqueConstraint:
            tableName: update_policy
            columnNames: app_code, platform
            constraintName: uq_update_policy_app_platform
'@
```

3) Domain, DTOs, Repository, Service, Controller

```powershell
# Entity
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater\domain | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\domain\UpdatePolicy.java -Value @'
package com.ujomorserver.updater.domain;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "update_policy", uniqueConstraints = @UniqueConstraint(name="uq_update_policy_app_platform", columnNames = {"app_code","platform"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UpdatePolicy {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name="app_code", nullable=false)
  private String appCode;
  @Column(name="platform", nullable=false)
  private String platform;
  @Column(name="latest_version", nullable=false)
  private String latestVersion;
  @Column(name="min_supported_version", nullable=false)
  private String minSupportedVersion;
  @Column(name="force_update", nullable=false)
  private boolean forceUpdate;
  @Column(name="recommended", nullable=false)
  private boolean recommended;
  private String releaseNotesUrl;
  private String updateUrl;
  private Integer cacheTtlSeconds;
}
'@

# Repository
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater\repo | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\repo\UpdatePolicyRepository.java -Value @'
package com.ujomorserver.updater.repo;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ujomorserver.updater.domain.UpdatePolicy;

public interface UpdatePolicyRepository extends JpaRepository<UpdatePolicy, Long> {
  Optional<UpdatePolicy> findByAppCodeAndPlatform(String appCode, String platform);
  List<UpdatePolicy> findByAppCode(String appCode);
}
'@

# DTOs
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater\api\dto | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\api\dto\PolicyRequest.java -Value @'
package com.ujomorserver.updater.api.dto;
import jakarta.validation.constraints.*;
public record PolicyRequest(
  @NotBlank String latestVersion,
  @NotBlank String minSupportedVersion,
  boolean forceUpdate,
  boolean recommended,
  String releaseNotesUrl,
  String updateUrl,
  Integer cacheTtlSeconds
) {}
'@

Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\api\dto\PolicyResponse.java -Value @'
package com.ujomorserver.updater.api.dto;
public record PolicyResponse(
  String appCode,
  String platform,
  String latestVersion,
  String minSupportedVersion,
  boolean forceUpdate,
  boolean recommended,
  String releaseNotesUrl,
  String updateUrl,
  Integer cacheTtlSeconds,
  // derived fields for convenience
  boolean updateAvailable,
  boolean supported
) {}
'@

# Service (with simple SemVer compare)
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater\service | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\service\PolicyService.java -Value @'
package com.ujomorserver.updater.service;
import com.ujomorserver.updater.api.dto.PolicyRequest;
import com.ujomorserver.updater.api.dto.PolicyResponse;
import com.ujomorserver.updater.domain.UpdatePolicy;
import com.ujomorserver.updater.repo.UpdatePolicyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PolicyService {
  private final UpdatePolicyRepository repo;
  public PolicyService(UpdatePolicyRepository repo) { this.repo = repo; }

  @Transactional
  public PolicyResponse upsert(String appCode, String platform, PolicyRequest req) {
    UpdatePolicy p = repo.findByAppCodeAndPlatform(appCode, platform)
        .orElseGet(() -> UpdatePolicy.builder().appCode(appCode).platform(platform).build());
    p.setLatestVersion(req.latestVersion());
    p.setMinSupportedVersion(req.minSupportedVersion());
    p.setForceUpdate(req.forceUpdate());
    p.setRecommended(req.recommended());
    p.setReleaseNotesUrl(req.releaseNotesUrl());
    p.setUpdateUrl(req.updateUrl());
    p.setCacheTtlSeconds(req.cacheTtlSeconds());
    UpdatePolicy saved = repo.save(p);
    return toResponse(saved, saved.getLatestVersion(), saved.getMinSupportedVersion());
  }

  @Transactional(readOnly = true)
  public PolicyResponse resolve(String appCode, String platform, String currentVersion) {
    UpdatePolicy p = repo.findByAppCodeAndPlatform(appCode, platform)
        .orElseThrow(() -> new IllegalArgumentException("No policy for app="+appCode+", platform="+platform));
    boolean updateAvailable = compareSemver(currentVersion, p.getLatestVersion()) < 0;
    boolean supported = compareSemver(currentVersion, p.getMinSupportedVersion()) >= 0;
    return new PolicyResponse(p.getAppCode(), p.getPlatform(), p.getLatestVersion(), p.getMinSupportedVersion(),
        p.isForceUpdate(), p.isRecommended(), p.getReleaseNotesUrl(), p.getUpdateUrl(), p.getCacheTtlSeconds(),
        updateAvailable, supported);
  }

  @Transactional(readOnly = true)
  public List<UpdatePolicy> list(String appCode) { return repo.findByAppCode(appCode); }

  private int compareSemver(String a, String b) {
    if (a == null || b == null) return 0;
    String[] aa = a.split("[.-]");
    String[] bb = b.split("[.-]");
    int n = Math.max(aa.length, bb.length);
    for (int i=0;i<n;i++) {
      int ai = i<aa.length ? parseIntSafe(aa[i]) : 0;
      int bi = i<bb.length ? parseIntSafe(bb[i]) : 0;
      if (ai != bi) return Integer.compare(ai, bi);
    }
    return 0;
  }
  private int parseIntSafe(String s){ try { return Integer.parseInt(s.replaceAll("[^0-9]","")); } catch(Exception e){ return 0; } }
}
'@

# Controller
New-Item -ItemType Directory -Force updater-service\src\main\java\com\ujomorserver\updater\api | Out-Null
Set-Content -Path updater-service\src\main\java\com\ujomorserver\updater\api\PolicyController.java -Value @'
package com.ujomorserver.updater.api;
import com.ujomorserver.updater.api.dto.*;
import com.ujomorserver.updater.domain.UpdatePolicy;
import com.ujomorserver.updater.service.PolicyService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/updates")
public class PolicyController {
  private final PolicyService service;
  public PolicyController(PolicyService service) { this.service = service; }

  @GetMapping("/policy")
  public ResponseEntity<PolicyResponse> resolve(@RequestParam String appCode,
                                                @RequestParam String platform,
                                                @RequestParam String currentVersion) {
    return ResponseEntity.ok(service.resolve(appCode, platform, currentVersion));
  }

  @GetMapping("/config/{appCode}")
  public ResponseEntity<List<UpdatePolicy>> list(@PathVariable String appCode) {
    return ResponseEntity.ok(service.list(appCode));
  }

  @PutMapping("/config/{appCode}/{platform}")
  public ResponseEntity<PolicyResponse> upsert(@PathVariable String appCode,
                                               @PathVariable String platform,
                                               @RequestBody @Valid PolicyRequest request) {
    return ResponseEntity.ok(service.upsert(appCode, platform, request));
  }
}
'@
```

4) Build the project and run the service (DEV)

```powershell
# Build shared libs then the new module fat jar
mvn -q -DskipTests -pl shared-security -am install
mvn -q -DskipTests -pl shared-utils -am install
mvn -q -DskipTests -pl updater-service -am package spring-boot:repackage

# Run locally (requires local MariaDB or docker-compose mariadb)
java -jar updater-service\target\updater-service-*.jar --spring.profiles.active=dev `
  --CONSUL_ENABLED=false `
  --SPRING_DATASOURCE_URL="jdbc:mariadb://localhost:3306/affiantordb?createDatabaseIfNotExist=true"
```

5) Seed policies (DEV)

```powershell
# After service is running on a random port (check logs), or add --server.port=8087
$base = "http://localhost:8087/api/v1/updates"

# Deponent Portal (Mobile)
Invoke-RestMethod -Method Put -Uri "$base/config/deponent/android" -ContentType 'application/json' -Body '{
  "latestVersion":"1.2.0","minSupportedVersion":"1.0.0","forceUpdate":false,
  "recommended":true,"releaseNotesUrl":"https://example.com/deponent/android/1.2.0",
  "updateUrl":"https://play.google.com/store/apps/details?id=com.affiantor.deponent", "cacheTtlSeconds":86400 }'

Invoke-RestMethod -Method Put -Uri "$base/config/deponent/ios" -ContentType 'application/json' -Body '{
  "latestVersion":"1.2.0","minSupportedVersion":"1.0.0","forceUpdate":false,
  "recommended":true,"releaseNotesUrl":"https://example.com/deponent/ios/1.2.0",
  "updateUrl":"https://apps.apple.com/app/id1234567890", "cacheTtlSeconds":86400 }'

# Notary Portal (Desktop)
Invoke-RestMethod -Method Put -Uri "$base/config/notary/windows" -ContentType 'application/json' -Body '{
  "latestVersion":"2.4.1","minSupportedVersion":"2.0.0","forceUpdate":false,
  "recommended":true,"releaseNotesUrl":"https://example.com/notary/windows/2.4.1",
  "updateUrl":"https://updates.affiantor.com/notary/windows/feed", "cacheTtlSeconds":86400 }'

Invoke-RestMethod -Method Put -Uri "$base/config/notary/macos" -ContentType 'application/json' -Body '{
  "latestVersion":"2.4.1","minSupportedVersion":"2.0.0","forceUpdate":false,
  "recommended":true,"releaseNotesUrl":"https://example.com/notary/macos/2.4.1",
  "updateUrl":"https://updates.affiantor.com/notary/macos/appcast.xml", "cacheTtlSeconds":86400 }'

# Web apps
Invoke-RestMethod -Method Put -Uri "$base/config/support/web" -ContentType 'application/json' -Body '{
  "latestVersion":"0.18.0","minSupportedVersion":"0.15.0","forceUpdate":false,
  "recommended":true,"releaseNotesUrl":"https://example.com/support/web/0.18.0",
  "updateUrl":"https://support.affiantor.com", "cacheTtlSeconds":300 }'
```

6) Client integration guidance
- Mobile (Android/iOS)
  - Query /policy at app start; if supported=false or forceUpdate=true, show blocking screen linking to store.
  - If updateAvailable && recommended, show non-blocking prompt; throttle prompts.
- Desktop (Windows/macOS)
  - Use external updater (Squirrel/Sparkle). Feed/URL comes from updateUrl. App may still call /policy to decide force update.
- Web
  - On successful deployment, bump latestVersion, optionally set recommended=true.
  - Clients periodically poll /policy; if updateAvailable, show “New version available — Reload” banner and refresh caches.
- Hybrid
  - Combine desktop auto-updater with in-app policy checks for critical enforcement.

7) API Gateway integration (dev)
- Add route to api-gateway application-*.yml (example):

```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: updater-service
          uri: lb://updater-service
          predicates:
            - Path=/api/v1/updates/**
          filters:
            - StripPrefix=0
```

8) Docker & Compose
- Build image with the shared Dockerfile:

```powershell
docker build -f tools\docker\Dockerfile.jvm --build-arg MODULE=updater-service -t affiantor/updater-service:dev .
```

- Example compose block (add to docker/docker-compose.yml):

```yaml
  updater-service:
    build:
      context: ..
      dockerfile: tools/docker/Dockerfile.jvm
      args:
        MODULE: updater-service
    pull_policy: build
    environment:
      SPRING_PROFILES_ACTIVE: dev
      CONSUL_HOST: consul
      CONSUL_PORT: 8500
      SPRING_DATASOURCE_URL: jdbc:mariadb://mariadb:3306/affiantordb?createDatabaseIfNotExist=true&sessionVariables=sql_mode='NO_ENGINE_SUBSTITUTION'&jdbcCompliantTruncation=false
      SPRING_DATASOURCE_USERNAME: affiantor
      SPRING_DATASOURCE_PASSWORD: affiantorpass
    depends_on:
      mariadb:
        condition: service_healthy
      consul:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/actuator/health/liveness"]
      interval: 15s
      timeout: 3s
      retries: 10
      start_period: 30s
    networks:
      - affiantor-net
```

Security Notes
- In production, protect PUT endpoints (admin role) using shared-security.
- Rate-limit GET /policy as needed; allow caching via cacheTtlSeconds on client side.

Operational Notes
- Policies are simple rows; manage via Admin UI (future) or API calls.
- Use Liquibase for schema migration; module uses the resilient datasource/dialect pattern already used across services.

Validation
- This module is additive and does not modify existing services.
- Uses the shared Dockerfile and matches our Consul/JPA patterns, minimizing integration risk.

Changelog
- 2025-09-13: Initial version.
