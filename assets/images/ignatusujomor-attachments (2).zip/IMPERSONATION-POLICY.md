# Impersonation Policy — Admin/Super Assisted Support

Date: 2025-09-20
Owners: Security, Platform Engineering, Support
Related: docs/runbooks/portals-signoff-checklist.md, user-activity-logger, api-gateway, authentication

Purpose
- Define when and how authorized staff may impersonate another user for support/diagnostics.
- Ensure strict auditing and safety controls are in place.

Who can impersonate
- Roles: SUPER, ADMIN, SUPPORT_SUPERVISOR (with change‑management approval). SUPPORT_AGENT may request but not execute.
- Dual control: A second SUPER/ADMIN must approve in production.

Pre‑conditions
- Active incident/ticket reference with justification.
- Target user consent when feasible; emergency exception must be recorded.

How it works (high‑level)
1) Admin UI initiates impersonation with target user ID and justification.
2) Backend issues a short‑lived impersonation token that:
   - Embeds original actor info (actorUserId, actorRoles, ticketId, justification)
   - Sets claim impersonating=true and impersonatedUserId
   - Reduces privileges to that of target user; never elevates.
3) Gateway/services accept token but add audit attributes to logs and activity store.
4) All actions are recorded to user-activity-logger with impersonation fields.

Audit fields (required)
- actorUserId, actorEmail
- impersonatedUserId, impersonatedEmail
- rolesAtIssue (actor)
- ticketId/incidentId
- justification
- correlationId (x-correlation-id)
- startedAt, endedAt

Headers to capture (for cross‑service propagation)
- x-impersonating: true|false
- x-impersonated-user: <userId>
- x-actor-user: <userId>
- x-impersonation-ticket: <ticketId>

Service responsibilities
- Deny dangerous operations while impersonating (e.g., delete, payout, role changes).
- Include audit fields in activity events; persist in user-activity-logger.
- Display impersonation banner in UI via claim/headers.

Verification checklist
- Unit: tokens with impersonating=true propagate through gateway; headers added; audit event contains all fields.
- Integration: sample action writes impersonation audit record.
- Ops: periodic review of impersonation logs; alerts on prolonged sessions.

Security notes
- Tokens must be short‑lived (<=15 minutes) and non‑refreshable.
- No nested impersonation.
- All impersonation flows behind ADMIN/SUPER guard; disabled by default in prod until approved.
