#!/usr/bin/env bash
# Affiantor helper: Deploy Amazon RDS for MariaDB with an optional Free Tier mode
# Usage (WSL/Linux):
#   ENVIRONMENT=staging REGION="eu-west-3" VPC_ID=vpc-xxxx PRIVATE_SUBNET_IDS="subnet-a,subnet-b" \
#   RDS_SG_ID=sg-xxxx DB_NAME=affiantor FREE_TIER=true DRY_RUN=true \
#     bash docs/aws/rds/snippets/deploy-rds.sh
#   # Then execute:
#   ENVIRONMENT=staging REGION="eu-west-3" VPC_ID=vpc-xxxx PRIVATE_SUBNET_IDS="subnet-a,subnet-b" \
#   RDS_SG_ID=sg-xxxx DB_NAME=affiantor FREE_TIER=true DRY_RUN=false CONFIRM=YES \
#     bash docs/aws/rds/snippets/deploy-rds.sh
#
# Behavior:
#   - Auto-detects/bootstraps the CloudFormation Service Role and uses --role-arn
#   - For DRY_RUN=true, creates a change set only (no execution) and shows recorded parameters/changes
#   - On apply, prints effective params, waits for completion, and on failure dumps stack events and parameters
#   - Uses ManageMasterUserPassword=true so credentials live in Secrets Manager automatically
#
# Requirements:
#   - AWS CLI v2 and jq
#   - Caller must have iam:PassRole for the CFN Service Role

set -euo pipefail

REGION=${REGION:-eu-west-3}
ENVIRONMENT=${ENVIRONMENT:-}
VPC_ID=${VPC_ID:-}
PRIVATE_SUBNET_IDS=${PRIVATE_SUBNET_IDS:-}
RDS_SG_ID=${RDS_SG_ID:-}
DB_NAME=${DB_NAME:-affiantor}
FREE_TIER=${FREE_TIER:-true}
ENGINE_VERSION=${ENGINE_VERSION:-auto}
DB_SECRET_ARN=${DB_SECRET_ARN:-}
DB_SECRET_JSON_KEY=${DB_SECRET_JSON_KEY:-password}
STACK_NAME=${STACK_NAME:-affiantor-rds-${ENVIRONMENT}}
TEMPLATE_FILE=${TEMPLATE_FILE:-docs/aws/rds/RDS-MARIADB.template.json}
DRY_RUN=${DRY_RUN:-true}
CONFIRM=${CONFIRM:-NO}
CHANGE_SET_NAME=${CHANGE_SET_NAME:-cs-$(date +%Y%m%d-%H%M%S)}
RECREATE_ON_ROLLBACK=${RECREATE_ON_ROLLBACK:-NO}
QUIET_PREFLIGHT=${QUIET_PREFLIGHT:-false}

is_truthy() {
  case "$1" in
    true|True|TRUE|yes|Yes|YES|y|Y|1) return 0 ;;
    *) return 1 ;;
  esac
}

# Auto-select a supported MariaDB engine version if ENGINE_VERSION=auto
# Preference order (highest first): 11.8.3, 11.4.8, 11.4.7, 11.4.5
select_engine_version() {
  local region="$1"
  local preferred=("11.8.3" "11.4.8" "11.4.7" "11.4.5")
  # Get all available engine versions for mariadb in the region
  local versions
  versions=$(aws rds describe-db-engine-versions \
    --region "$region" \
    --engine mariadb \
    --query 'DBEngineVersions[].EngineVersion' \
    --output text 2>/dev/null | tr '\t' '\n')
  if [[ -z "$versions" ]]; then
    # fallback to default-only (some principals may be restricted)
    local def
    def=$(aws rds describe-db-engine-versions --region "$region" --engine mariadb --default-only \
      --query 'DBEngineVersions[0].EngineVersion' --output text 2>/dev/null || true)
    if [[ -n "$def" && "$def" != "None" ]]; then
      echo "$def"; return 0
    fi
    # ultimate fallback to documented safe default
    echo "11.4.8"; return 0
  fi
  # Try preferred list first
  for p in "${preferred[@]}"; do
    if printf '%s\n' $versions | grep -Fxq "$p"; then
      echo "$p"; return 0
    fi
  done
  # Otherwise pick the highest version returned (sort -V to version sort)
  echo "$versions" | sort -V | tail -n1
}

# Normalize subnet list (remove spaces and duplicate IDs while preserving order)
normalize_subnets() {
  local raw="$1"
  local cleaned=$(echo "$raw" | sed 's/,\s*/,/g')
  IFS=',' read -r -a arr <<< "$cleaned"
  local seen=""
  local out=()
  for id in "${arr[@]}"; do
    id=$(echo "$id" | xargs)
    [[ -z "$id" ]] && continue
    if [[ ",$seen," != *",$id,"* ]]; then
      out+=("$id"); seen+="$id,"
    fi
  done
  (IFS=','; echo "${out[*]}")
}

# Validate inputs
if [[ -z "$ENVIRONMENT" || -z "$VPC_ID" || -z "$PRIVATE_SUBNET_IDS" || -z "$RDS_SG_ID" ]]; then
  echo "[ERROR] Required: ENVIRONMENT, VPC_ID, PRIVATE_SUBNET_IDS (comma-separated), RDS_SG_ID" >&2
  exit 2
fi
if [[ "$ENVIRONMENT" != "staging" && "$ENVIRONMENT" != "prod" ]]; then
  echo "[ERROR] ENVIRONMENT must be 'staging' or 'prod'." >&2
  exit 2
fi
# Validate DB_NAME against template's AllowedPattern [a-zA-Z0-9_]+
if [[ ! "$DB_NAME" =~ ^[A-Za-z0-9_]+$ ]]; then
  echo "[ABORT] DB_NAME '$DB_NAME' is invalid. Use only letters, numbers, and underscore (e.g., affiantorstgDb)." >&2
  exit 2
fi

# Lightweight VPC existence check (help catch typos like vpc-xxxx)
VPC_CHECK_OK=0
VPC_CHECK_DEFER=0
if aws ec2 describe-vpcs --region "$REGION" --vpc-ids "$VPC_ID" --query 'Vpcs[0].VpcId' --output text >/dev/null 2>&1; then
  VPC_CHECK_OK=1
else
  VPC_CHECK_DEFER=1  # retry after assuming CFN role
fi
SUBNETS=$(normalize_subnets "$PRIVATE_SUBNET_IDS")

# Subnet preflight: ensure at least two subnets, belong to VPC_ID, and span >=2 AZs
IFS=',' read -r -a SUBNET_ARR <<< "$SUBNETS"
if (( ${#SUBNET_ARR[@]} < 2 )); then
  echo "[ABORT] Provide at least two subnet IDs in PRIVATE_SUBNET_IDS (comma-separated)." >&2
  exit 2
fi

# Describe subnets in one call; if not authorized under current caller, we will retry via the CFN Service Role later
SKIP_SUBNET_PREFLIGHT=0
if ! SUBNET_DESC_JSON=$(aws ec2 describe-subnets --region "$REGION" --subnet-ids ${SUBNETS//,/ } --query 'Subnets[].{SubnetId:SubnetId,VpcId:VpcId,Az:AvailabilityZone,Cidr:CidrBlock}' --output json 2>/dev/null); then
  echo "[INFO] Could not describe subnets with current credentials (likely missing ec2:DescribeSubnets). Will attempt preflight via CloudFormation Service Role."
  SKIP_SUBNET_PREFLIGHT=1
fi

if (( SKIP_SUBNET_PREFLIGHT == 0 )); then
  # Verify VPC match and collect AZs
  MISMATCH=0
  AZS=()
  for sid in "${SUBNET_ARR[@]}"; do
    v=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .VpcId")
    az=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .Az")
    cidr=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .Cidr")
    if [[ -z "$v" || "$v" == "null" ]]; then
      echo "[ABORT] Subnet '$sid' was not found in region $REGION." >&2
      exit 2
    fi
    if [[ "$v" != "$VPC_ID" ]]; then
      echo "[ABORT] Subnet '$sid' (CIDR $cidr, AZ $az) belongs to VPC '$v', not '$VPC_ID'." >&2
      MISMATCH=1
    fi
    AZS+=("$az")
    echo "[INFO] Subnet $sid -> VPC=$v AZ=$az CIDR=$cidr"
  done
  if (( MISMATCH == 1 )); then
    echo "[ABORT] One or more provided subnets are not in VPC '$VPC_ID'." >&2
    exit 2
  fi
  # Distinct AZ count
  UNIQ_AZS=$(printf "%s\n" "${AZS[@]}" | sort -u | wc -l | tr -d ' ')
  if (( UNIQ_AZS < 2 )); then
    echo "[ABORT] The provided subnets are not in at least two distinct Availability Zones. Pick subnets across >=2 AZs." >&2
    exit 2
  fi
fi

# Ensure CFN Service Role exists and get ROLE_ARN
resolve_cfn_role() {
  local arn
  arn=$(aws cloudformation describe-stacks \
    --region "$REGION" \
    --stack-name Affiantor-CFN-Deploy-Role \
    --query "Stacks[0].Outputs[?OutputKey=='RoleArn'].OutputValue" \
    --output text 2>/dev/null || true)
  if [[ -n "$arn" && "$arn" != "None" ]]; then
    echo "$arn"; return 0
  fi
  if [[ -f docs/aws/cloudformation/snippets/get-or-create-cfn-role.sh ]]; then
    echo "[INFO] CFN service role not found. Bootstrapping..." >&2
    local out
    out=$(REGION="$REGION" bash docs/aws/cloudformation/snippets/get-or-create-cfn-role.sh)
    echo "$out" | sed -n 's/^ROLE_ARN=//p' | head -n1
  fi
}

ROLE_ARN=${ROLE_ARN:-}
if [[ -z "$ROLE_ARN" || "$ROLE_ARN" == "None" ]]; then
  ROLE_ARN="$(resolve_cfn_role || true)"
fi
if [[ -z "$ROLE_ARN" || "$ROLE_ARN" == "None" ]]; then
  echo "[ERROR] Could not resolve ROLE_ARN. Ensure the CFN Service Role exists and your caller can pass it." >&2
  exit 1
fi

echo "[INFO] Using CFN Service Role: $ROLE_ARN"

# If initial subnet preflight was skipped due to missing DescribeSubnets, retry using the CFN Service Role via STS
if (( SKIP_SUBNET_PREFLIGHT == 1 )); then
  CREDS_JSON=$(aws sts assume-role --region "$REGION" --role-arn "$ROLE_ARN" --role-session-name "affiantor-rds-preflight-$$" --duration-seconds 900 2>/dev/null || true)
  if [[ -n "${CREDS_JSON:-}" && "$CREDS_JSON" != "None" ]]; then
    AKID=$(echo "$CREDS_JSON" | jq -r '.Credentials.AccessKeyId // empty')
    SAK=$(echo "$CREDS_JSON" | jq -r '.Credentials.SecretAccessKey // empty')
    STK=$(echo "$CREDS_JSON" | jq -r '.Credentials.SessionToken // empty')
    if [[ -n "$AKID" && -n "$SAK" && -n "$STK" ]]; then
      # If needed, retry VPC existence check under the assumed role
      if (( VPC_CHECK_OK == 0 && VPC_CHECK_DEFER == 1 )); then
        if AWS_ACCESS_KEY_ID="$AKID" AWS_SECRET_ACCESS_KEY="$SAK" AWS_SESSION_TOKEN="$STK" \
             aws ec2 describe-vpcs --region "$REGION" --vpc-ids "$VPC_ID" --query 'Vpcs[0].VpcId' --output text >/dev/null 2>&1; then
          VPC_CHECK_OK=1
          echo "[INFO] VPC '$VPC_ID' verified via CloudFormation Service Role."
        else
          if $QUIET_PREFLIGHT; then
            echo "[INFO] Could not verify VPC via CloudFormation Service Role. Proceeding; CloudFormation will validate VPC at deploy time."
          else
            echo "[WARN] Could not verify VPC via CloudFormation Service Role. Proceeding; CloudFormation will validate VPC at deploy time."
          fi
        fi
      fi
      # Run describe-subnets under the assumed role in a subshell
      if SUBNET_DESC_JSON=$(AWS_ACCESS_KEY_ID="$AKID" AWS_SECRET_ACCESS_KEY="$SAK" AWS_SESSION_TOKEN="$STK" \
          aws ec2 describe-subnets --region "$REGION" --subnet-ids ${SUBNETS//,/ } \
            --query 'Subnets[].{SubnetId:SubnetId,VpcId:VpcId,Az:AvailabilityZone,Cidr:CidrBlock}' --output json 2>/dev/null); then
        echo "[INFO] Subnet/AZ preflight validated via CloudFormation Service Role."
        SKIP_SUBNET_PREFLIGHT=0
        # Perform the same VPC/AZ validation now that we have the description
        MISMATCH=0
        AZS=()
        for sid in "${SUBNET_ARR[@]}"; do
          v=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .VpcId")
          az=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .Az")
          cidr=$(echo "$SUBNET_DESC_JSON" | jq -r ".[] | select(.SubnetId==\"$sid\") | .Cidr")
          if [[ -z "$v" || "$v" == "null" ]]; then
            echo "[ABORT] Subnet '$sid' was not found in region $REGION." >&2
            exit 2
          fi
          if [[ "$v" != "$VPC_ID" ]]; then
            echo "[ABORT] Subnet '$sid' (CIDR $cidr, AZ $az) belongs to VPC '$v', not '$VPC_ID'." >&2
            MISMATCH=1
          fi
          AZS+=("$az")
          echo "[INFO] Subnet $sid -> VPC=$v AZ=$az CIDR=$cidr"
        done
        if (( MISMATCH == 1 )); then
          echo "[ABORT] One or more provided subnets are not in VPC '$VPC_ID'." >&2
          exit 2
        fi
        UNIQ_AZS=$(printf "%s\n" "${AZS[@]}" | sort -u | wc -l | tr -d ' ')
        if (( UNIQ_AZS < 2 )); then
          echo "[ABORT] The provided subnets are not in at least two distinct Availability Zones. Pick subnets across >=2 AZs." >&2
          exit 2
        fi
      else
        echo "[WARN] Could not describe subnets even via CloudFormation Service Role. Skipping subnet/AZ preflight validation and relying on CloudFormation to validate."
      fi
    else
      echo "[WARN] Unable to parse credentials from sts:AssumeRole response. Skipping subnet/AZ preflight validation."
    fi
  else
    if $QUIET_PREFLIGHT; then
      echo "[INFO] Could not assume CloudFormation Service Role for subnet preflight. Skipping subnet/AZ preflight validation."
    else
      echo "[WARN] Could not assume CloudFormation Service Role for subnet preflight. Skipping subnet/AZ preflight validation."
    fi
  fi
fi

# Resolve ENGINE_VERSION if set to auto/latest
if [[ "$ENGINE_VERSION" == "auto" || "$ENGINE_VERSION" == "AUTO" || "$ENGINE_VERSION" == "latest" ]]; then
  EV_SELECTED=$(select_engine_version "$REGION")
  echo "[INFO] ENGINE_VERSION auto-selected for region $REGION: $EV_SELECTED"
  ENGINE_VERSION="$EV_SELECTED"
fi

echo "[INFO] Effective parameters: ENVIRONMENT=$ENVIRONMENT REGION=$REGION STACK_NAME=$STACK_NAME"
echo "[INFO] Template: $TEMPLATE_FILE"
echo "[INFO] VPC_ID=$VPC_ID, PRIVATE_SUBNET_IDS=$SUBNETS, RDS_SG_ID=$RDS_SG_ID, DB_NAME=$DB_NAME, ENGINE_VERSION=$ENGINE_VERSION, FREE_TIER=$FREE_TIER"
if [[ -n "$DB_SECRET_ARN" ]]; then
  echo "[INFO] Using existing DB secret: DB_SECRET_ARN=$DB_SECRET_ARN (json key: $DB_SECRET_JSON_KEY)"
else
  echo "[INFO] Using RDS-managed master user secret (ManageMasterUserPassword=true)"
fi

# Template validation preflight
if ! aws cloudformation validate-template --region "$REGION" --template-body file://"$TEMPLATE_FILE" >/dev/null 2>&1; then
  echo "[ABORT] CloudFormation validate-template failed for $TEMPLATE_FILE. Check template syntax and intrinsics." >&2
  aws cloudformation validate-template --region "$REGION" --template-body file://"$TEMPLATE_FILE" || true
  exit 2
fi

# Helper to get stack status
get_stack_status() {
  aws cloudformation describe-stacks --region "$REGION" --stack-name "$STACK_NAME" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo "NOT_FOUND"
}

# Handle ROLLBACK_COMPLETE on apply similar to VPC helper
if ! is_truthy "$DRY_RUN"; then
  STATUS=$(get_stack_status)
  if [[ "$STATUS" == "ROLLBACK_COMPLETE" ]]; then
    if is_truthy "$RECREATE_ON_ROLLBACK"; then
      echo "[INFO] Stack '$STACK_NAME' is ROLLBACK_COMPLETE. RECREATE_ON_ROLLBACK is true — deleting before recreate..."
      aws cloudformation delete-stack --region "$REGION" --stack-name "$STACK_NAME" || true
      echo "[INFO] Waiting for stack delete-complete..."
      aws cloudformation wait stack-delete-complete --region "$REGION" --stack-name "$STACK_NAME" || true
    else
      echo "[ABORT] Stack '$STACK_NAME' is ROLLBACK_COMPLETE. Re-run with RECREATE_ON_ROLLBACK=YES to auto-delete before apply." >&2
      exit 2
    fi
  fi
fi

# Common parameters for CFN
PARAM_KV=(
  ParameterKey=Environment,ParameterValue="$ENVIRONMENT" \
  ParameterKey=VpcId,ParameterValue="$VPC_ID" \
  ParameterKey=PrivateSubnetIds,ParameterValue="$SUBNETS" \
  ParameterKey=RdsSecurityGroupId,ParameterValue="$RDS_SG_ID" \
  ParameterKey=DbName,ParameterValue="$DB_NAME" \
  ParameterKey=EngineVersion,ParameterValue="$ENGINE_VERSION" \
  ParameterKey=FreeTierMode,ParameterValue="$FREE_TIER"
)
# Append secret usage parameters
if [[ -n "$DB_SECRET_ARN" ]]; then
  PARAM_KV+=( \
    ParameterKey=UseExistingMasterSecret,ParameterValue="true" \
    ParameterKey=MasterPasswordSecretArn,ParameterValue="$DB_SECRET_ARN" \
    ParameterKey=MasterPasswordSecretJsonKey,ParameterValue="$DB_SECRET_JSON_KEY" \
  )
else
  PARAM_KV+=( ParameterKey=UseExistingMasterSecret,ParameterValue="false" )
fi

if is_truthy "$DRY_RUN"; then
  echo "[PLAN] Creating change set only (no execution). ChangeSet: $CHANGE_SET_NAME"
  CS_TYPE=CREATE
  if aws cloudformation describe-stacks --region "$REGION" --stack-name "$STACK_NAME" >/dev/null 2>&1; then
    CS_TYPE=UPDATE
  fi

  # Build JSON parameters file to avoid AWS CLI shorthand parsing issues with comma-delimited lists
  TMP_DIR="${TMPDIR:-/tmp}"
  PARAM_FILE="$TMP_DIR/rds_params_${STACK_NAME}_$$.json"
  echo "[INFO] Preparing parameters JSON at $PARAM_FILE"
  jq -n \
    --arg env "$ENVIRONMENT" \
    --arg vpc "$VPC_ID" \
    --arg subnets "$SUBNETS" \
    --arg sg "$RDS_SG_ID" \
    --arg db "$DB_NAME" \
    --arg ev "$ENGINE_VERSION" \
    --arg ft "$FREE_TIER" \
    --arg useSecret "$( [[ -n "$DB_SECRET_ARN" ]] && echo true || echo false )" \
    --arg secretArn "${DB_SECRET_ARN:-}" \
    --arg secretKey "${DB_SECRET_JSON_KEY:-password}" \
    '
    [
      {"ParameterKey":"Environment","ParameterValue":$env},
      {"ParameterKey":"VpcId","ParameterValue":$vpc},
      {"ParameterKey":"PrivateSubnetIds","ParameterValue":$subnets},
      {"ParameterKey":"RdsSecurityGroupId","ParameterValue":$sg},
      {"ParameterKey":"DbName","ParameterValue":$db},
      {"ParameterKey":"EngineVersion","ParameterValue":$ev},
      {"ParameterKey":"FreeTierMode","ParameterValue":$ft}
    ] + (
      if $useSecret == "true" then
        [
          {"ParameterKey":"UseExistingMasterSecret","ParameterValue":"true"},
          {"ParameterKey":"MasterPasswordSecretArn","ParameterValue":$secretArn},
          {"ParameterKey":"MasterPasswordSecretJsonKey","ParameterValue":$secretKey}
        ]
      else
        [ {"ParameterKey":"UseExistingMasterSecret","ParameterValue":"false"} ]
      end
    )
    ' > "$PARAM_FILE"

  aws cloudformation create-change-set \
    --region "$REGION" \
    --stack-name "$STACK_NAME" \
    --template-body file://"$TEMPLATE_FILE" \
    --role-arn "$ROLE_ARN" \
    --capabilities CAPABILITY_NAMED_IAM \
    --change-set-name "$CHANGE_SET_NAME" \
    --change-set-type "$CS_TYPE" \
    --parameters file://"$PARAM_FILE" >/dev/null
  echo "[INFO] Waiting for change set to be created..."
  aws cloudformation wait change-set-create-complete --region "$REGION" --change-set-name "$CHANGE_SET_NAME" --stack-name "$STACK_NAME" || true
  echo "[INFO] Change set details:" 
  aws cloudformation list-change-sets --region "$REGION" --stack-name "$STACK_NAME" --query 'Summaries[*].{Name:ChangeSetName,Status:Status,StatusReason:StatusReason,ExecutionStatus:ExecutionStatus}' --output table || true
  aws cloudformation describe-change-set --region "$REGION" --stack-name "$STACK_NAME" --change-set-name "$CHANGE_SET_NAME" --output table || true
  echo "[NEXT] Execute with: aws cloudformation execute-change-set --region $REGION --stack-name $STACK_NAME --change-set-name $CHANGE_SET_NAME"
  # Cleanup temp file
  rm -f "$PARAM_FILE" 2>/dev/null || true
  exit 0
fi

# Apply path uses deploy for convenience
PARAM_OVERRIDES=(
  --parameter-overrides \
    Environment="$ENVIRONMENT" \
    VpcId="$VPC_ID" \
    PrivateSubnetIds="$SUBNETS" \
    RdsSecurityGroupId="$RDS_SG_ID" \
    DbName="$DB_NAME" \
    EngineVersion="$ENGINE_VERSION" \
    FreeTierMode="$FREE_TIER"
)
# Append secret usage overrides
if [[ -n "$DB_SECRET_ARN" ]]; then
  PARAM_OVERRIDES+=( \
    UseExistingMasterSecret="true" \
    MasterPasswordSecretArn="$DB_SECRET_ARN" \
    MasterPasswordSecretJsonKey="$DB_SECRET_JSON_KEY" \
  )
else
  PARAM_OVERRIDES+=( UseExistingMasterSecret="false" )
fi

set +e
set -x
aws cloudformation deploy \
  --region "$REGION" \
  --stack-name "$STACK_NAME" \
  --template-file "$TEMPLATE_FILE" \
  --role-arn "$ROLE_ARN" \
  --capabilities CAPABILITY_NAMED_IAM \
  "${PARAM_OVERRIDES[@]}"
DEPLOY_EXIT=$?
set +x
set -e

if (( DEPLOY_EXIT != 0 )); then
  echo "[ERROR] aws cloudformation deploy failed with exit code $DEPLOY_EXIT"
  echo "[INFO] Template file used: $TEMPLATE_FILE"
  echo "[INFO] Recent stack events for '$STACK_NAME':"
  aws cloudformation describe-stack-events --region "$REGION" --stack-name "$STACK_NAME" --output table 2>/dev/null || echo "[INFO] Stack may not exist yet."
  echo "[INFO] Stack parameters as seen by CloudFormation (if stack exists):"
  aws cloudformation describe-stacks --region "$REGION" --stack-name "$STACK_NAME" --query 'Stacks[0].Parameters' --output table 2>/dev/null || true
  echo "[HINT] Ensure ENGINE_VERSION is available in region $REGION for MariaDB."
  echo "[HINT] Auto-select is supported: set ENGINE_VERSION=auto (prefers 11.8.3, 11.4.8, 11.4.7, 11.4.5)."
  echo "[HINT] List available versions: aws rds describe-db-engine-versions --region $REGION --engine mariadb --query \"DBEngineVersions[].EngineVersion\" --output text"
  echo "[HINT] Provide at least two subnets from the same VPC across two AZs (use DataSubnetIds from the VPC stack outputs)."
  echo "[HINT] If the stack is in ROLLBACK_COMPLETE, rerun with RECREATE_ON_ROLLBACK=YES to auto-delete before apply."
  exit $DEPLOY_EXIT
fi

echo "[INFO] Waiting for stack to complete (create/update)..."
aws cloudformation wait stack-create-complete --region "$REGION" --stack-name "$STACK_NAME" 2>/dev/null || \
aws cloudformation wait stack-update-complete --region "$REGION" --stack-name "$STACK_NAME" 2>/dev/null || true

get_output() {
  local key=$1
  aws cloudformation describe-stacks \
    --region "$REGION" \
    --stack-name "$STACK_NAME" \
    --query "Stacks[0].Outputs[?OutputKey=='${key}'].OutputValue | [0]" \
    --output text 2>/dev/null || true
}

RDS_ENDPOINT_HOST=$(get_output EndpointAddress)
RDS_ENDPOINT_PORT=$(get_output EndpointPort)
RDS_SECRET_ARN=$(get_output MasterUserSecretArn)

echo "RDS_ENDPOINT=${RDS_ENDPOINT_HOST}:${RDS_ENDPOINT_PORT}"
echo "RDS_SECRET_ARN=${RDS_SECRET_ARN}"
export RDS_ENDPOINT RDS_SECRET_ARN

echo "[TIP] ECS tasks can read DB creds via Secrets Manager JSON keys (username, password, host, port, dbname). See docs/aws/secretsmanager/SECRETS-NAMING.md"
