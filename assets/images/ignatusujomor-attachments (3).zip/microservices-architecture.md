# Affiantor Microservices Architecture

Date: 2025-08-28
Owner: Platform Engineering

This document visualizes the relationships among Affiantor microservices, their interactions (sync/async), data flow, gateways, and dependencies. It was derived from the repository structure, configuration (parent POMs, application.yml), and service naming conventions. Missing links inferred from shared utilities and gateway notes are included and marked as [inferred].

## Legend
- Rectangles: Microservices
- Cylinders: Datastores
- Parallelogram: External Systems
- Hexagon: API Gateway
- Solid arrows: Synchronous HTTP (REST)
- Dashed arrows: Asynchronous messaging (if/when introduced) [inferred]
- Dotted arrows: Service discovery/tracing/metrics relationships
- Colors:
  - Blue: Core domain services
  - Green: Edge/gateway
  - Orange: Cross-cutting (security, shared libs)
  - Purple: Observability

## High-Level Diagram (Mermaid)
```mermaid
flowchart LR
  subgraph Edge[Edge]
    APIGW[[API Gateway]]:::gateway
  end

  subgraph CrossCutting[Cross-Cutting]
    SHSEC[shared-security]:::cross
    SHUTIL[shared-utils]:::cross
    TRACE[(Zipkin / OTEL Collector)]:::observe
    CONSUL[(Consul Service Discovery)]:::observe
    PROM[(Prometheus)]:::observe
  end

  subgraph UserDomain[User & Identity]
    AUTH[authentication\nAuthN/Login/JWT]:::core
    UAC[user-account-authentication-credentials]:::core
    UAR[user-account-recovery]:::core
    BDP[basic-detail-profile]:::core
    CDP[contact-detail-profile]:::core
    UIP[user-identity-profile\nKYC/Verification]:::core
  end

  subgraph ActivityDomain[Activity]
    UAL[user-activity-logger]:::core
    NAC[notary-activity]:::core
    AAC[agency-activity]:::core
  end

  subgraph AffidavitDomain[Affidavit]
    AFF[affidavit-service]:::core
    TPL[affidavit-template-builder]:::core
    DOC[document-manager]:::core
    CMN[comments-service]:::core
  end

  subgraph CommerceDomain[Commerce]
    PAY[payments-service]:::core
    LIC[licence-manager]:::core
  end

  subgraph NotificationDomain[Notifications]
    EMAIL[email-notification]:::core
  end

  MET[metrics-service]:::core
  ADM[admin-monitoring]:::core

  %% Datastores (per service, inferred logical DBs)
  AUTHDB[(Auth DB)]:::db
  USERDB[(User/Profile DB)]:::db
  AFFDB[(Affidavit DB)]:::db
  DOCSTORE[(Doc Storage)]:::db
  PAYDB[(Payments DB)]:::db
  LOGDB[(Activity/Logs DB)]:::db
  METDB[(Metrics DB)]:::db

  %% API Gateway routes
  APIGW -->|HTTP route| AUTH
  APIGW -->|HTTP route| UIP
  APIGW -->|HTTP route| BDP
  APIGW -->|HTTP route| CDP
  APIGW -->|HTTP route| AFF
  APIGW -->|HTTP route| DOC
  APIGW -->|HTTP route| CMN
  APIGW -->|HTTP route| PAY
  APIGW -->|HTTP route| EMAIL
  APIGW -->|HTTP route| LIC

  %% Service Discovery
  AUTH -.-> CONSUL
  UIP -.-> CONSUL
  BDP -.-> CONSUL
  CDP -.-> CONSUL
  AFF -.-> CONSUL
  DOC -.-> CONSUL
  CMN -.-> CONSUL
  PAY -.-> CONSUL
  EMAIL -.-> CONSUL
  LIC -.-> CONSUL
  MET -.-> CONSUL
  UAL -.-> CONSUL
  NAC -.-> CONSUL
  AAC -.-> CONSUL
  ADM -.-> CONSUL

  %% Observability
  AUTH -.trace.-> TRACE
  UIP -.trace.-> TRACE
  BDP -.trace.-> TRACE
  CDP -.trace.-> TRACE
  AFF -.trace.-> TRACE
  DOC -.trace.-> TRACE
  CMN -.trace.-> TRACE
  PAY -.trace.-> TRACE
  EMAIL -.trace.-> TRACE
  LIC -.trace.-> TRACE
  MET -.trace.-> TRACE
  UAL -.trace.-> TRACE
  NAC -.trace.-> TRACE
  AAC -.trace.-> TRACE
  ADM -.trace.-> TRACE
  AUTH -.metrics.-> PROM
  classDef core fill:#e6f0ff,stroke:#5b8def,color:#0b3d91
  classDef gateway fill:#e1f7e1,stroke:#2e7d32,color:#1b5e20
  classDef cross fill:#ffeacc,stroke:#ff9800,color:#e65100
  classDef observe fill:#f3e5f5,stroke:#8e24aa,color:#4a148c
  classDef db fill:#fff8e1,stroke:#f9a825,color:#6d4c41

  %% Data stores connections (ownership boundaries)
  AUTH --> AUTHDB
  UAC --> AUTHDB
  UAR --> AUTHDB
  BDP --> USERDB
  CDP --> USERDB
  UIP --> USERDB
  CMN --> AFFDB
  AFF --> AFFDB
  TPL --> AFFDB
  DOC --> DOCSTORE
  PAY --> PAYDB
  UAL --> LOGDB
  MET --> METDB

  %% Inter-service sync HTTP calls (inferred typical flows)
  AFF -->|verify user| UIP
  AFF -->|fetch profile| BDP
  AFF -->|notify| EMAIL
  AFF -->|store files| DOC
  AFF -->|comments| CMN
  PAY -->|charge| AUTH
  PAY -->|notify| EMAIL
  LIC -->|verify user| AUTH
  DOC -->|generate QR/sign| ADM
  CDP -->|audit| UAL
  BDP -->|audit| UAL
  AUTH -->|audit| UAL

  %% Asynchronous events [inferred]
  AFF -.event-> EMAIL
  PAY -.event-> EMAIL
  UAL -.event-> MET
```

Notes:
- All services register with Consul for discovery; API Gateway uses service IDs to route requests (see docs/SERVICE-BOUNDARY.md).
- Tracing via Micrometer OTel bridge + Zipkin reporter; metrics via Prometheus registries are enabled in multiple modules.
- Error handling and resilience: parent POM includes resilience4j; common strategies such as timeouts, retries, and circuit breakers are recommended for inter-service calls [inferred].

## Service Summaries
- api-gateway: Entry point; routes public HTTP to downstream services using Consul. Planned JWT validation and rate limiting.
- authentication: Issues JWTs, login/logout, refresh tokens.
- confirmation-token: Manages email/token confirmations.
- basic-detail-profile: Manages basic user profile details.
- contact-detail-profile: Manages contact details; enforces ownership and security guards.
- user-identity-profile: KYC/identity verification, exposes DTO endpoints for identity summary.
- user-account-authentication-credentials: Internal auth credentials management.
- user-account-recovery: Password/Account recovery flows.
- address: Address management microservice.
- email-notification: Sends emails on domain events.
- document-manager: Document generation/storage; QR code and PDF generation.
- affidavit-service: Affidavit workflows; uses template builder and document manager.
- affidavit-template-builder: Builds affidavit templates.
- comments-service: Comments on documents/affidavits.
- payments-service: Payment intents and PSP integration [skeleton/in progress].
- licence-manager: License issuance/validation.
- agency-centre/notary-centre: Domain centers for agency/notary operations.
- agency-activity/notary-activity: Activity logs for respective domains.
- user-activity-logger: Central user activity logging.
- admin-monitoring: Administrative/ops monitoring UI/backend.
- metrics-service: Custom app metrics ingestion and summary (HTTP) for BI and dashboards.

## Error Handling and Fallbacks
- Use resilience4j (circuit breaker, retry, rate limiter) on inter-service HTTP clients.
- Standardize timeouts and bulkheads. Propagate correlation IDs.
- Define graceful degradation: e.g., if email-notification is unavailable, queue messages for later [inferred].

## External Systems
- Consul for service discovery and health checks.
- Zipkin/OTel for tracing; Prometheus for metrics scraping.
- SMTP server for outbound emails (configurable via Spring Mail).

## How to Update
- When adding a new service, register in Consul and add a route in api-gateway.
- Update this diagram with new interactions (add arrows and datastore as needed).

# Affiantor Microservices Architecture

Date: 2025-08-28
Owner: Platform Engineering

This document visualizes the relationships among Affiantor microservices, their interactions (sync/async), data flow, gateways, and dependencies. It was derived from the repository structure, configuration (parent POMs, application.yml), and service naming conventions. Missing links inferred from shared utilities and gateway notes are included and marked as [inferred].

## Legend
- Rectangles: Microservices
- Cylinders: Datastores
- Parallelogram: External Systems
- Hexagon: API Gateway
- Solid arrows: Synchronous HTTP (REST)
- Dashed arrows: Asynchronous messaging (if/when introduced) [inferred]
- Dotted arrows: Service discovery/tracing/metrics relationships
- Colors:
  - Blue: Core domain services
  - Green: Edge/gateway
  - Orange: Cross-cutting (security, shared libs)
  - Purple: Observability

## High-Level Diagram (Mermaid)
```mermaid
flowchart LR
  subgraph Edge[Edge]
    APIGW[[API Gateway]]:::gateway
  end

  subgraph CrossCutting[Cross-Cutting]
    SHSEC[shared-security]:::cross
    SHUTIL[shared-utils]:::cross
    TRACE[(Zipkin / OTEL Collector)]:::observe
    CONSUL[(Consul Service Discovery)]:::observe
    PROM[(Prometheus)]:::observe
  end

  subgraph UserDomain[User & Identity]
    AUTH[authentication\nAuthN/Login/JWT]:::core
    UAC[user-account-authentication-credentials]:::core
    UAR[user-account-recovery]:::core
    BDP[basic-detail-profile]:::core
    CDP[contact-detail-profile]:::core
    UIP[user-identity-profile\nKYC/Verification]:::core
  end

  subgraph ActivityDomain[Activity]
    UAL[user-activity-logger]:::core
    NAC[notary-activity]:::core
    AAC[agency-activity]:::core
  end

  subgraph AffidavitDomain[Affidavit]
    AFF[affidavit-service]:::core
    TPL[affidavit-template-builder]:::core
    DOC[document-manager]:::core
    CMN[comments-service]:::core
  end

  subgraph CommerceDomain[Commerce]
    PAY[payments-service]:::core
    LIC[licence-manager]:::core
  end

  subgraph NotificationDomain[Notifications]
    EMAIL[email-notification]:::core
  end

  MET[metrics-service]:::core
  ADM[admin-monitoring]:::core
  UPD[updater-service]:::core

  %% Datastores (per service, inferred logical DBs)
  AUTHDB[(Auth DB)]:::db
  USERDB[(User/Profile DB)]:::db
  AFFDB[(Affidavit DB)]:::db
  DOCSTORE[(Doc Storage)]:::db
  PAYDB[(Payments DB)]:::db
  LOGDB[(Activity/Logs DB)]:::db
  METDB[(Metrics DB)]:::db

  %% API Gateway routes
  APIGW -->|HTTP route| AUTH
  APIGW -->|HTTP route| UIP
  APIGW -->|HTTP route| BDP
  APIGW -->|HTTP route| CDP
  APIGW -->|HTTP route| AFF
  APIGW -->|HTTP route| DOC
  APIGW -->|HTTP route| CMN
  APIGW -->|HTTP route| PAY
  APIGW -->|HTTP route| EMAIL
  APIGW -->|HTTP route| LIC
  APIGW -->|HTTP route| UPD

  %% Service Discovery
  AUTH -.-> CONSUL
  UIP -.-> CONSUL
  BDP -.-> CONSUL
  CDP -.-> CONSUL
  AFF -.-> CONSUL
  DOC -.-> CONSUL
  CMN -.-> CONSUL
  PAY -.-> CONSUL
  EMAIL -.-> CONSUL
  LIC -.-> CONSUL
  MET -.-> CONSUL
  UAL -.-> CONSUL
  NAC -.-> CONSUL
  AAC -.-> CONSUL
  ADM -.-> CONSUL
  UPD -.-> CONSUL

  %% Observability
  AUTH -.trace.-> TRACE
  UIP -.trace.-> TRACE
  BDP -.trace.-> TRACE
  CDP -.trace.-> TRACE
  AFF -.trace.-> TRACE
  DOC -.trace.-> TRACE
  CMN -.trace.-> TRACE
  PAY -.trace.-> TRACE
  EMAIL -.trace.-> TRACE
  LIC -.trace.-> TRACE
  MET -.trace.-> TRACE
  UAL -.trace.-> TRACE
  NAC -.trace.-> TRACE
  AAC -.trace.-> TRACE
  ADM -.trace.-> TRACE
  UPD -.trace.-> TRACE
  AUTH -.metrics.-> PROM
  classDef core fill:#e6f0ff,stroke:#5b8def,color:#0b3d91
  classDef gateway fill:#e1f7e1,stroke:#2e7d32,color:#1b5e20
  classDef cross fill:#ffeacc,stroke:#ff9800,color:#e65100
  classDef observe fill:#f3e5f5,stroke:#8e24aa,color:#4a148c
  classDef db fill:#fff8e1,stroke:#f9a825,color:#6d4c41

  %% Data stores connections (ownership boundaries)
  AUTH --> AUTHDB
  UAC --> AUTHDB
  UAR --> AUTHDB
  BDP --> USERDB
  CDP --> USERDB
  UIP --> USERDB
  CMN --> AFFDB
  AFF --> AFFDB
  TPL --> AFFDB
  DOC --> DOCSTORE
  PAY --> PAYDB
  UAL --> LOGDB
  MET --> METDB
```

Notes:
- All services register with Consul for discovery; API Gateway uses service IDs to route requests (see docs/SERVICE-BOUNDARY.md).
- Tracing via Micrometer OTel bridge + Zipkin reporter; metrics via Prometheus registries are enabled in multiple modules.
- Error handling and resilience: parent POM includes resilience4j; common strategies such as timeouts, retries, and circuit breakers are recommended for inter-service calls [inferred].

## Service Summaries
- api-gateway: Entry point; routes public HTTP to downstream services using Consul. Planned JWT validation and rate limiting.
- authentication: Issues JWTs, login/logout, refresh tokens.
- confirmation-token: Manages email/token confirmations.
- basic-detail-profile: Manages basic user profile details.
- contact-detail-profile: Manages contact details; enforces ownership and security guards.
- user-identity-profile: KYC/identity verification, exposes DTO endpoints for identity summary.
- user-account-authentication-credentials: Internal auth credentials management.
- user-account-recovery: Password/Account recovery flows.
- address: Address management microservice.
- email-notification: Sends emails on domain events.
- document-manager: Document generation/storage; QR code and PDF generation.
- affidavit-service: Affidavit workflows; uses template builder and document manager.
- affidavit-template-builder: Builds affidavit templates.
- comments-service: Comments on documents/affidavits.
- payments-service: Payment intents and PSP integration [skeleton/in progress].
- licence-manager: License issuance/validation.
- agency-centre/notary-centre: Domain centers for agency/notary operations.
- agency-activity/notary-activity: Activity logs for respective domains.
- user-activity-logger: Central user activity logging.
- admin-monitoring: Administrative/ops monitoring UI/backend.
- metrics-service: Custom app metrics ingestion and summary (HTTP) for BI and dashboards.
- updater-service: Returns app update policies; admin endpoints to configure per-app/platform policies.

## Error Handling and Fallbacks
- Use resilience4j (circuit breaker, retry, rate limiter) on inter-service HTTP clients.
- Standardize timeouts and bulkheads. Propagate correlation IDs.
- Define graceful degradation: e.g., if email-notification is unavailable, queue messages for later [inferred].

## External Systems
- Consul for service discovery and health checks.
- Zipkin/OTel for tracing; Prometheus for metrics scraping.
- SMTP server for outbound emails (configurable via Spring Mail).

## How to Update
- When adding a new service, register in Consul and add a route in api-gateway.
- Update this diagram with new interactions (add arrows and datastore as needed).
