# Service Performance Monitoring (SPM) — Get Started

Overview
- SPM aggregates distributed tracing data into RED metrics (Rate, Errors, Duration) and visualizes them per service and operation.
- This project uses Micrometer, Spring Boot Actuator, and OpenTelemetry/Jaeger for tracing. Prometheus provides the time‑series database for metrics.
- Jaeger UI is available via the Admin Monitoring UI, either embedded or linked directly. SPM dashboards can be built in Grafana from Prometheus metrics and enriched with Jaeger trace exemplars.

Prerequisites
- Running Jaeger (dev: tools\jaeger\docker-compose.yml; staging/prod: your cluster’s collector + UI)
- Prometheus (scraping /actuator/prometheus endpoints of all services)
- Optional: Grafana for dashboards

Key Endpoints per Service
- Health: GET /actuator/health
- Info: GET /actuator/info
- Metrics: GET /actuator/metrics
- Prometheus scrape: GET /actuator/prometheus

Configuration Notes
- Prometheus scrape should include all microservices and admin-monitoring. Use relabeling to attach service labels from application name.
- Tracing propagation: W3C and B3 are enabled via shared-security. Ensure gateway forwards x-correlation-id and trace headers (already configured).
- For production, prefer running the OpenTelemetry Java Agent rather than baking exporters into the JVM. Configure exporters via environment variables (see docs/OBSERVABILITY-JAEGER.md).

Building RED Metrics (Recommended)
- HTTP server request metrics are exposed by default in Spring Boot 3 with Micrometer:
  - http_server_requests_seconds_count (Rate)
  - http_server_requests_seconds_sum / _bucket (Duration/latency percentiles)
  - Errors derived from status >= 500 (Error rate)
- Suggested PromQL for dashboards:
  - Rate (RPS): sum(rate(http_server_requests_seconds_count{outcome!="REDIRECTION"}[5m])) by (service)
  - Error Rate: sum(rate(http_server_requests_seconds_count{status=~"5.."}[5m])) by (service)
  - P95 latency: histogram_quantile(0.95, sum by (le, service)(rate(http_server_requests_seconds_bucket[5m])))
  - P99 latency: histogram_quantile(0.99, sum by (le, service)(rate(http_server_requests_seconds_bucket[5m])))
- Ensure your Prometheus scrape attaches a label service=<spring.application.name> or uses job instance mapping.

Jaeger + Exemplars (Optional)
- You can configure Grafana to show trace exemplars from Jaeger next to latency graphs.
- Export exemplars via OTLP when using the OTel Java Agent; Grafana Agent can assist with pipeline management.

Local Development Quick Start
1) Start Jaeger: powershell -ExecutionPolicy Bypass -File tools\jaeger\up.ps1
2) Start Prometheus: powershell -ExecutionPolicy Bypass -File tools\prometheus\up.ps1
   - Open http://localhost:9090 → Status → Service Discovery/Targets to verify scraping.
   - Services are discovered automatically from Consul using management_port and management_context_path metadata; no manual target editing is required for Affiantor services.
3) Start services (mvn -pl <service> spring-boot:run) ensuring management endpoints enabled (in shared-security).
4) Open Admin Monitoring UI at http://localhost:9090/ops and click Jaeger UI (or http://localhost:16686). Then open the Monitor tab in Jaeger; once Prometheus is scraping your services, the RED metrics charts will render.

Security
- In production, restrict /actuator/* and Prometheus scrape endpoints to internal networks. Gateway already permits /actuator/prometheus by default for in‑cluster scraping; adjust policy as needed.

References
- docs/OBSERVABILITY-JAEGER.md — environment setup, agents, and endpoints
- docs/NEXT-STEPS.md — sprint tasks; Observability section
- docs/BACKEND-COMPLETION-CHECKLIST.md — metrics/tracing acceptance criteria
