# Affiantor AWS ECS/RDS Stabilization and Redeployment Guide

This guide summarizes the root cause, the AWS infrastructure checks, and the exact changes required in IAM, Security Groups, ECS task/service settings, and application configuration to stabilize deployments for staging/prod.

Root cause (from logs)
- The Spring Boot container failed to initialize the JPA EntityManager due to database connectivity errors:
  - java.sql.SQLNonTransientConnectionException: Socket fail to connect to affiantor-staging-mariadb.cluster-...eu-west-3.rds.amazonaws.com:3306
- ECS deployment circuit breaker rolled back because containers repeatedly failed to pass health checks during startup.

What needs to be true in AWS for stable startups
1) VPC and Security Groups
- ECS Tasks MUST run in subnets that have network reachability to the RDS/Aurora cluster (typically private subnets with NAT if needed).
- RDS Security Group inbound rule must allow traffic from the ECS Task Security Group:
  - Type: MySQL/Aurora
  - Port: 3306
  - Source: <ECS_TASK_SG_ID>
- ECS Task Security Group should allow egress to 0.0.0.0/0 (or at least to the RDS SG over port 3306) and to AWS endpoints (Secrets Manager, ECR, CloudWatch Logs).

2) IAM roles and policies
- Task execution role (ECS task pulls images and writes logs) typically needs ECR, logs, and optional KMS decryption.
- Application task role must allow reading the DB secret (and KMS decrypt if secret is encrypted with a CMK).

Example: Task role policy for Secrets Manager/KMS
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": [
        "arn:aws:secretsmanager:eu-west-3:<ACCOUNT_ID>:secret:affiantordb-staging-*",
        "arn:aws:secretsmanager:eu-west-3:<ACCOUNT_ID>:secret:affiantordb-prod-*",
        "arn:aws:secretsmanager:eu-west-3:<ACCOUNT_ID>:secret:/config/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "kms:Decrypt"
      ],
      "Resource": "*",
      "Condition": {
        "ForAnyValue:StringEquals": {
          "kms:EncryptionContextKeys": ["aws:secretsmanager:secret-arn"]
        }
      }
    }
  ]
}

Notes:
- Scope down Resource ARNs to your actual secret ARNs if known.
- If you use a customer-managed KMS key for the secret, include that key ARN in the kms:Decrypt Resource instead of "*".

3) ECS Service configuration
- HealthCheckGracePeriodSeconds: set to at least 90–120 seconds to allow Spring Boot to start (and download JIT/AOT, initialize JPA, etc.).
- DeploymentConfiguration:
  DeploymentCircuitBreaker:
    Enable: true
    Rollback: true
- DesiredCount: 1+ (scale as needed).

CloudFormation snippet (ECS Service excerpt)
Resources:
  AuthenticationService:
    Type: AWS::ECS::Service
    Properties:
      Cluster: !Ref Cluster
      ServiceName: authentication
      LaunchType: FARGATE
      DesiredCount: 1
      TaskDefinition: !Ref AuthenticationTaskDef
      NetworkConfiguration:
        AwsvpcConfiguration:
          AssignPublicIp: DISABLED
          SecurityGroups: [ !Ref EcsTaskSecurityGroup ]
          Subnets: [ !Ref PrivateSubnetA, !Ref PrivateSubnetB ]
      DeploymentConfiguration:
        DeploymentCircuitBreaker:
          Enable: true
          Rollback: true
      HealthCheckGracePeriodSeconds: 120

4) Task definition environment and secrets
- Ensure AWS_REGION=eu-west-3 (or leave autodetection if running in eu-west-3).
- You do NOT need to pass DB creds via env. The app reads the secret affiantordb-${spring.profiles.active} from Secrets Manager.
- The shared security profile also imports optional secrets /config/${spring.application.name} and /config/application if present.

5) Secrets Manager content validation
Run in your AWS environment (or AWS CloudShell):
aws secretsmanager get-secret-value \
  --secret-id affiantordb-staging \
  --region eu-west-3 \
  --query SecretString \
  --output text | jq .

Expected JSON keys (examples):
{
  "host": "affiantor-staging-mariadb.cluster-xxxx.eu-west-3.rds.amazonaws.com",
  "port": 3306,
  "dbname": "affiantor",
  "username": "app_user",
  "password": "*****"
}

- Host must resolve inside the VPC where ECS runs.
- The username must exist in the DB and have appropriate privileges (CONNECT, CRUD on your schema).

6) Database (RDS/Aurora) security
- Parameter group and option group standard configs are fine.
- Ensure the DB is in available status and subnet group matches ECS VPC subnets.

Application-side tuning (already applied in repo)
- Datasource uses AWS Secrets Manager by default; falls back to local spring.datasource.* only if explicitly enabled and aws retrieval fails in non-AWS contexts.
- Scheduled refresh every 5 minutes and Spring Retry (3 attempts with backoff) handle secret rotation.
- New defaults in shared-security for staging/prod set Hikari minIdle=0 by default to avoid aggressive initial connections during cold start. You can override via env:
  - AFFIANTOR_DS_MIN_IDLE (default 0)
  - AFFIANTOR_DS_MAX_SIZE (default 10)
  - AFFIANTOR_DS_CONN_TIMEOUT_MS (default 30000)
  - AFFIANTOR_DS_VALIDATION_TIMEOUT_MS (default 5000)

Pre-deployment checklist
1. Secrets
- affiantordb-staging and affiantordb-prod exist and contain valid JSON as above.
- Task role has secretsmanager:GetSecretValue (and kms:Decrypt if needed) on those secrets.

2. Networking
- ECS task subnets and RDS subnets are in the same VPC or connected via routing.
- RDS SG inbound allows ECS Task SG on 3306.
- ECS Task SG allows egress to RDS and AWS endpoints.

3. ECS Service
- HealthCheckGracePeriodSeconds >= 90
- Circuit breaker enabled (rollback true)
- DesiredCount >= 1

4. Observability
- CloudWatch Logs enabled on task
- Optional: OTEL/Zipkin endpoints are either disabled or reachable

Runtime debugging tips
- Launch a one-off debug task in the same subnets/SGs using amazonlinux image and test connectivity:
  - yum install -y nc bind-utils mariadb105
  - getent hosts affiantor-staging-mariadb.cluster-xxxx.eu-west-3.rds.amazonaws.com
  - nc -vz affiantor-staging-mariadb.cluster-xxxx.eu-west-3.rds.amazonaws.com 3306
  - mysql -h <host> -u <user> -p -P 3306
- If DNS or port fails, fix SG/subnets first.

Rollback/Recovery
- If circuit breaker keeps rolling back, temporarily increase grace period and set desired count to 0, then back to 1 after networking fix.
- You can disable rollback for deeper debugging, but re-enable after fix.

Notes for local testing
- For local runs without AWS permissions, you can set:
  - affiantor.datasource.use-aws-secrets=false
  - spring.datasource.url=jdbc:h2:mem:testdb (or local MariaDB)
- Do not use these settings in ECS.

Contact points
- RDS/Aurora admin: verify DB user grants and password policy
- Networking: verify SG and subnet routing
- IAM: verify task role policies
- Platform: ECS service/task definition changes
