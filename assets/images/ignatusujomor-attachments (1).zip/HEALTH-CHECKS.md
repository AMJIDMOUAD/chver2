# Health Checks & Dashboards Registration

Date: 2025-09-20
Owners: Platform Engineering, SRE
Related: api-gateway (application-*.yml), admin-monitoring, metrics-service, docs/backend/CORS-POLICY.md, docs/backend/OPENAPI-AGGREGATION.md

Overview
- Goal: Ensure all backend services expose standard health and metrics endpoints and are registered in dashboards/monitors.
- Method: Use Spring Boot Actuator for health/info and Micrometer Prometheus registry for metrics. Scrape via Prometheus; visualize in Grafana.

Standard Endpoints
- Liveness/Readiness: /actuator/health (with probes enabled)
- Info: /actuator/info
- Metrics (Prometheus): /actuator/prometheus

API Gateway (this repo)
- Exposure per environment:
  - application-dev.yml → management.endpoints.web.exposure.include: health,info,metrics,prometheus
  - application-staging.yml → same
  - application-prod.yml → same
- Health probes enabled: management.endpoint.health.probes.enabled=true across all profiles.
- Tracing: W3C propagation enabled; OTLP local endpoint in dev can be set via management.otlp.tracing.endpoint.

Other Services
- Follow shared-security profile defaults which already include Actuator + Prometheus. Verify service-specific application-*.yml expose prometheus in production.

Dashboards Registration
- Prometheus scrape target: gateway → https://gw.<env>.affiantor.xyz/actuator/prometheus
- Suggested Grafana dashboards:
  - JVM (Micrometer) — Dashboard ID: 4701
  - Spring Boot 3 / Micrometer — Dashboard ID: 19098
  - API Gateway (custom) — Dashboard Slug: affiantor-api-gateway
- Add service label via Micrometer common tags where applicable: management.metrics.tags.application=api-gateway; management.metrics.tags.instance=<hostname>

Alerting & SLO Monitors
- Health check: alert if /actuator/health != UP for 2 minutes.
- Error rate: 5xx rate over 5 minutes > 1% triggers page in prod, notify in staging.
- Latency: p95 gateway latency > 1s for 10 minutes triggers warning.

Runbook
- Verify endpoints:
  - curl -s https://gw.dev.affiantor.xyz/actuator/health | jq .status  → "UP"
  - curl -s https://gw.dev.affiantor.xyz/actuator/prometheus | head
- Add to Prometheus scrape config:
  - job_name: affiantor-gateway
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: ["gw.dev.affiantor.xyz"]
- Grafana: Import dashboards listed above. Set "application" variable to api-gateway.

Notes
- Correlation ID is propagated and can be used in logs/traces; metrics are aggregate and do not include PII.
- If you need to disable Prometheus temporarily, remove it from exposure include and redeploy.
