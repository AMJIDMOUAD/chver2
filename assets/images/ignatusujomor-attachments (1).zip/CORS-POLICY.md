# CORS Policy — Portals

Date: 2025-09-20
Owners: Platform Engineering, Security
Related: api-gateway (application-*.yml), docs/runbooks/portals-signoff-checklist.md

Overview
- This document defines the allowed origins for cross-origin requests hitting the API Gateway from the three portals: Deponent, Notary, Support Desk, and the Control Centre Nexus (admin).
- Enforcement is performed at the API Gateway layer using Spring Cloud Gateway global CORS configuration.

Configuration (by environment)
- Development
  - Allowed origins (default): http://localhost:3000, http://localhost:5173 (override via CORS_ALLOWED_ORIGINS env var)
  - Location: api-gateway/src/main/resources/application-dev.yml → spring.cloud.gateway.globalcors
- Staging
  - Allowed origins (default, override via CORS_ALLOWED_ORIGINS):
    - https://nexus.staging.affiantor.xyz
    - https://notary.staging.affiantor.xyz
    - https://support.staging.affiantor.xyz
    - https://deponent.staging.affiantor.xyz
  - Location: api-gateway/src/main/resources/application-staging.yml → spring.cloud.gateway.globalcors
- Production
  - Allowed origins (default, override via CORS_ALLOWED_ORIGINS):
    - https://nexus.affiantor.xyz
    - https://notary.affiantor.xyz
    - https://support.affiantor.xyz
    - https://deponent.affiantor.xyz
  - Location: api-gateway/src/main/resources/application-prod.yml → spring.cloud.gateway.globalcors

Rules
- No wildcard allowed in production; explicit origins only.
- Allowed methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
- Allowed headers: Authorization, Content-Type, x-correlation-id, Accept-Language
- Exposed headers: x-correlation-id
- Credentials: allowed

Operational Notes
- For emergency block, remove an origin from the list and redeploy the gateway (or update config via externalized config if enabled).
- Correlation ID is required on all requests and is exposed in responses; use it to trace CORS-related errors.
- For preflight requests (OPTIONS), the gateway permits them and returns the appropriate CORS headers.
