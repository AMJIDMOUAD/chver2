### Database migration strategy with Hibernate ddl-auto=none

This document describes the safe, secure, and fast approach used by all Affiantor services to create and evolve database schemas in staging and production without relying on Hibernate auto DDL.

Key goals
- Never let Hibernate mutate schemas implicitly (ddl-auto=none)
- Avoid ECS deployment failures when the DB/DNS is briefly unavailable at boot
- Ensure migrations apply automatically once a service can reach the database
- Keep rollouts idempotent and safe across multiple replicas

What changed
- A shared, post-start Liquibase runner was added in shared-utils that:
  - Waits for the database to be reachable
  - Applies the service’s Liquibase changelog using the application DataSource (AWS Secrets Manager credentials)
  - Retries with exponential backoff (default up to ~10 minutes) without crashing the app
  - Relies on Liquibase’s DATABASECHANGELOGLOCK table to serialize migrations across replicas safely

Relevant configs
- shared-utils (applies to all services that depend on it):
  - spring.liquibase.enabled=false (keeps Spring Boot’s early Liquibase runner off)
  - affiantor.liquibase.deferred-enabled=true (turns on the deferred runner)
  - affiantor.liquibase.retry.max-attempts=120
  - affiantor.liquibase.retry.initial-delay-ms=1000
  - affiantor.liquibase.retry.max-delay-ms=30000
- Each service keeps its own Liquibase changelog path, e.g.
  - spring.liquibase.change-log=classpath:db/changelog/db.changelog-master-<service>.yaml
- DataSource is provided via AWS Secrets Manager (affiantordb-<profile>) and Hikari connects lazily.

Operational flow during deploy
1) Service starts normally even if RDS DNS isn’t ready (no fatal DB preflight).
2) After the app is up, the deferred runner attempts to get a DB connection.
3) Once a connection is obtained, Liquibase applies pending changesets.
4) If the DB is not yet reachable, it keeps retrying with exponential backoff until max-attempts is reached. The application keeps serving non-DB endpoints during this time.

How to enable per service
- Ensure the service declares its changelog (already present in most services):
  - spring.liquibase.change-log: classpath:db/changelog/db.changelog-master-<service>.yaml
- Ensure ddl-auto is none in the service profile (staging/prod), e.g.:
  - spring.jpa.hibernate.ddl-auto: none
- No other per-service change required when depending on shared-utils.

How to temporarily disable deferred migrations
- Set affiantor.liquibase.deferred-enabled=false for a specific service (staging/prod) if you need to skip migrations (not recommended for normal rollouts).
- Alternatively, you can re-enable Spring Boot’s built-in Liquibase by setting spring.liquibase.enabled=true and disabling the deferred runner.

Tuning retries
- affiantor.liquibase.retry.max-attempts: total number of attempts (default 120)
- affiantor.liquibase.retry.initial-delay-ms: first wait (default 1s)
- affiantor.liquibase.retry.max-delay-ms: max backoff cap (default 30s)

Security and safety
- Uses the same application DataSource configured via AWS Secrets Manager; no extra credentials.
- Liquibase locks ensure only one instance performs migrations at a time.
- Migrations are idempotent by design; failures in one attempt are retried cleanly.

Rollback and fail-fast options
- To fail fast for a particular rollout (not typical): set affiantor.liquibase.deferred-enabled=false and spring.liquibase.enabled=true (Boot’s Liquibase runs during startup and will fail the pod if migrations can’t apply).
- To roll back a bad change, use Liquibase rollback tags in your changelog and trigger a roll-forward/fix release or emergency rollback as per change-management policy.

Verification checklist per deployment
- Confirm the service lists its Liquibase changelog path in application-<profile>.yml.
- Confirm ddl-auto=none in staging/prod.
- Deploy the service. Watch logs for lines like:
  - "Running Liquibase changelog 'classpath:db/changelog/db.changelog-master-<service>.yaml'"
  - "Liquibase migration completed successfully"
- If retries were needed, you will see warnings with attempt counters; these are expected during short-lived DNS/DB delays.

Overrides
- For services that do NOT use a database, nothing runs; no action required.
- To scope migrations by environment, use Liquibase contexts/labels and pass via:
  - affiantor.liquibase.contexts and affiantor.liquibase.labels

Summary
- Hibernate will not create/alter tables in staging/prod.
- Liquibase runs safely after startup, once DB is reachable, with retry and locking to avoid race conditions.
- Defaults are centralized in shared-utils; services can override behavior via profile properties when necessary.
